/** Automatically generated file. DO NOT MODIFY */
package com.example.gothrough;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}