package com.example.gothrough;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;


public class DownBar extends RelativeLayout{

	private Button leftButton,rightButton,middleButton;
	
	private int leftTextColor;
	private int leftBackground;
	private String leftText;
	
	private int rightTextColor;
	private int rightBackground;
	private String rightText;
	
	private int middleTextColor;
	private int middleBackground;
	private String middleText;
	
	private LayoutParams leftParams,rightParams,middleParams;
	
	private downbarClickListener listener;
	
	public interface downbarClickListener{
		public void leftClick();
		public void rightClick();
		public void middleClick();
	}
	
	public void setOnDownbarClickListener(downbarClickListener listener){
		this.listener=listener;
	}
	
	public DownBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		TypedArray ta =context.obtainStyledAttributes(attrs,R.styleable.DownBar);
		leftTextColor=ta.getColor(R.styleable.DownBar_leftTextColor, 0);
		//leftBackground=ta.getDrawable(R.styleable.DownBar_leftBackground);
		leftBackground=ta.getColor(R.styleable.DownBar_leftBackground,0);
		leftText=ta.getString(R.styleable.DownBar_leftText);
	
		rightTextColor=ta.getColor(R.styleable.DownBar_rightTextColor, 0);
		//rightBackground=ta.getDrawable(R.styleable.DownBar_rightBackground);
		rightBackground=ta.getColor(R.styleable.DownBar_rightBackground,0);
		rightText=ta.getString(R.styleable.DownBar_rightText);
		
		middleTextColor=ta.getColor(R.styleable.DownBar_middleTextColor, 0);
		//middleBackground=ta.getDrawable(R.styleable.DownBar_middleBackground);
		middleBackground=ta.getColor(R.styleable.DownBar_middleBackground,0);
		middleText=ta.getString(R.styleable.DownBar_middleText);
		
		ta.recycle();
		
		leftButton = new Button(context);
		rightButton = new Button(context);
		middleButton = new Button(context);
		
		leftButton.setTextColor(leftTextColor);
		//leftButton.setBackground(leftBackground);
		leftButton.setBackgroundColor(leftBackground);
		leftButton.setText(leftText);
		//leftButton.setGravity(Gravity.LEFT);
		
		rightButton.setTextColor(rightTextColor);
		//rightButton.setBackground(rightBackground);
		rightButton.setBackgroundColor(rightBackground);
		rightButton.setText(rightText);
		//rightButton.setGravity(Gravity.RIGHT);
		
		middleButton.setTextColor(middleTextColor);
		//middleButton.setBackground(middleBackground);
		middleButton.setBackgroundColor(middleBackground);
		middleButton.setText(middleText);
		middleButton.setGravity(Gravity.CENTER);
		
		setBackgroundColor(0xFFFFFFFF);
		
		leftParams =new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
		leftParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
		addView(leftButton,leftParams);
		
		rightParams =new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
		rightParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
		addView(rightButton,rightParams);
		
		middleParams =new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
		middleParams.addRule(RelativeLayout.CENTER_IN_PARENT);
		addView(middleButton,middleParams);	
		
		leftButton.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				listener.leftClick();
			}
			
		});
		
		rightButton.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				listener.rightClick();
			}
			
		});
		
		middleButton.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				listener.middleClick();
			}
			
		});
		
	}



}
