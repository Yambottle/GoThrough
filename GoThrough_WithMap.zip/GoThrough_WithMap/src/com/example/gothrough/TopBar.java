package com.example.gothrough;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;


public class TopBar extends RelativeLayout{

	private Button leftButton,rightButton;
	private TextView tvtitle;
	
	private int leftTextColor;
	private int leftBackground;
	private String leftText;
	
	private int rightTextColor;
	private int rightBackground;
	private String rightText;
	
	private int titleTextColor;
	private int titleTextSize;
	private String title;
	
	private LayoutParams leftParams,rightParams,titleParams;
	
	private TopbarClickListener listener;
	
	public interface TopbarClickListener{
		public void leftClick();
		public void rightClick();
	}
	
	public void setOnTopbarClickListener(TopbarClickListener listener){
		this.listener=listener;
	}
	
	public TopBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		TypedArray ta =context.obtainStyledAttributes(attrs,R.styleable.TopBar);
		leftTextColor=ta.getColor(R.styleable.TopBar_TopleftTextColor, 0);
		//leftBackground=ta.getDrawable(R.styleable.TopBar_leftBackground);
		leftBackground=ta.getColor(R.styleable.TopBar_TopleftBackground,0);
		leftText=ta.getString(R.styleable.TopBar_TopleftText);
	
		rightTextColor=ta.getColor(R.styleable.TopBar_ToprightTextColor, 0);
		//rightBackground=ta.getDrawable(R.styleable.TopBar_rightBackground);
		rightBackground=ta.getColor(R.styleable.TopBar_ToprightBackground,0);
		rightText=ta.getString(R.styleable.TopBar_ToprightText);
		
		titleTextColor=ta.getColor(R.styleable.TopBar_ToptitleTextColor, 0);
		//middleBackground=ta.getDrawable(R.styleable.TopBar_middleBackground);
		titleTextSize=(int) ta.getDimension(R.styleable.TopBar_ToptitleTextSize,0);
		title=ta.getString(R.styleable.TopBar_Toptitle);
		
		ta.recycle();
		
		leftButton = new Button(context);
		rightButton = new Button(context);
		tvtitle = new TextView(context);
		
		leftButton.setTextColor(leftTextColor);
		//leftButton.setBackground(leftBackground);
		leftButton.setBackgroundColor(leftBackground);
		leftButton.setText(leftText);
		//leftButton.setGravity(Gravity.LEFT);
		
		rightButton.setTextColor(rightTextColor);
		//rightButton.setBackground(rightBackground);
		rightButton.setBackgroundColor(rightBackground);
		rightButton.setText(rightText);
		//rightButton.setGravity(Gravity.RIGHT);
		
		tvtitle.setTextColor(titleTextColor);
		//tvtitle.setBackground(middleBackground);
		tvtitle.setTextSize(titleTextSize);
		tvtitle.setText(title);
		tvtitle.setGravity(Gravity.CENTER);
		
		setBackgroundColor(0xFFFFFFFF);
		
		leftParams =new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
		leftParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
		addView(leftButton,leftParams);
		
		rightParams =new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
		rightParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
		addView(rightButton,rightParams);
		
		titleParams =new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.MATCH_PARENT);
		titleParams.addRule(RelativeLayout.CENTER_IN_PARENT);
		addView(tvtitle,titleParams);	
		
		leftButton.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				listener.leftClick();
			}
			
		});
		
		rightButton.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				listener.rightClick();
			}
			
		});
		
	}



}
