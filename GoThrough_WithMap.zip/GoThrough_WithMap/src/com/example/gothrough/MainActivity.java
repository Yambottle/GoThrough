package com.example.gothrough;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.gothrough.DownBar.downbarClickListener;
import com.example.gothrough.TopBar.TopbarClickListener;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

public class MainActivity extends Activity implements OnItemClickListener,OnScrollListener {

	private ListView lv;
	private SimpleAdapter sa;
	private List<Map<String,Object>> dataList;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		//DownBar
		DownBar downbar=(DownBar) findViewById(R.id.downbar);
		downbar.setOnDownbarClickListener(new downbarClickListener() {
			@Override
			public void rightClick() {
				// TODO Auto-generated method stub
				Toast.makeText(MainActivity.this, "right", Toast.LENGTH_SHORT).show();
			}
			
			@Override
			public void middleClick() {
				// TODO Auto-generated method stub
				
				Intent intent =new Intent(MainActivity.this, MapActivity.class);
				startActivity(intent);
			}
			
			
			@Override
			public void leftClick() {
				// TODO Auto-generated method stub
				Toast.makeText(MainActivity.this, "left", Toast.LENGTH_SHORT).show();
			}
		});
		//TopBar
		TopBar Topbar=(TopBar)findViewById(R.id.topbar);
		Topbar.setOnTopbarClickListener(new TopbarClickListener() {
			
			@Override
			public void rightClick() {
				// TODO Auto-generated method stub
				Toast.makeText(MainActivity.this, "right", Toast.LENGTH_SHORT).show();
			}
			
			@Override
			public void leftClick() {
				// TODO Auto-generated method stub
				Toast.makeText(MainActivity.this, "left", Toast.LENGTH_SHORT).show();
			}
		});
		//ListView
		lv=(ListView)findViewById(R.id.listView1);
		dataList =new ArrayList<Map<String, Object>>();
		sa=new SimpleAdapter(MainActivity.this, getData(),R.layout.itemlayout, new String[]{"img","item_title","img_content","item_content"}, new int[]{R.id.img,R.id.item_title,R.id.img_content,R.id.item_content});
		lv.setAdapter(sa);
		lv.setOnItemClickListener(this);
		lv.setOnScrollListener(this);
	}
	
	private List<Map<String,Object>> getData(){
		
		for(int i=0;i<20;i++){//iΪ����
			Map<String,Object> map=new HashMap<String,Object>();
			map.put("img", R.drawable.ic_launcher);
			map.put("item_title", "Blog");
			map.put("img_content", R.drawable.ic_launcher);
			map.put("item_content", "Blog_Content");
			dataList.add(map);
		}
		return dataList;
	}

	@Override
	public void onScroll(AbsListView arg0, int arg1, int arg2, int arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onScrollStateChanged(AbsListView view, int scollState) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		// TODO Auto-generated method stub
		Intent intent =new Intent(MainActivity.this, BlogActivity.class);
		startActivity(intent);
	}
	
}
