package com.example.gothrough;

import com.example.gothrough.TopBar.TopbarClickListener;
import android.app.Activity;
import android.os.Bundle;

public class BlogActivity extends Activity{

	@Override
	protected void onCreate(Bundle saveInstanceState) {
		super.onCreate(saveInstanceState);
		setContentView(R.layout.activity_blog);
		
		TopBar tBar =(TopBar)findViewById(R.id.blogtopbar);
		tBar.setOnTopbarClickListener(new TopbarClickListener() {
			
			@Override
			public void rightClick() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void leftClick() {
				// TODO Auto-generated method stub
				finish();
			}
		});
	}

	
}
