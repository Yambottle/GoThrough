package com.example.gpsdemo;

import android.app.Activity;
import android.content.Context;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		getLocation();
	}
	
	public void getLocation(){
		LocationManager locationManager;
		String serviceName =Context.LOCATION_SERVICE;
		locationManager =(LocationManager)getSystemService(serviceName);
		
		Criteria criteria =new Criteria();
		criteria.setAccuracy(Criteria.ACCURACY_FINE);
		criteria.setAltitudeRequired(false);
		criteria.setBearingRequired(false);
		criteria.setCostAllowed(true);
		criteria.setPowerRequirement(Criteria.POWER_LOW);
		String provider= locationManager.getBestProvider(criteria, true);
		Location location = locationManager.getLastKnownLocation(provider);
		updateWithNewLocation(location);
		locationManager.requestLocationUpdates(provider, 2000, 10, locationListener);
	}

	//
	String latLongString;
	public void updateWithNewLocation(Location location) {
		// TODO Auto-generated method stub
		TextView myLocationText;
		myLocationText = (TextView)findViewById(R.id.myLocationText);
		if(location!=null){
			double lat=location.getLatitude();
			double lng=location.getLongitude();
			latLongString="Latitude: "+lat+"\nLongitude: "+lng;
		}else{
			latLongString="Acquire GPS fail.";
		}
		myLocationText.setText("The Location Coordinate is:\n"+latLongString);
	}
	
	private final LocationListener locationListener=new LocationListener(){
		public void onLocationChanged(Location location){
			updateWithNewLocation(location);
		}
		public void onProviderDisabled(String provider){
			updateWithNewLocation(null);
		}
		public void onProviderEnabled(String provider){
		}
		public void onStatusChanged(String provider,int status,Bundle extras){
		}
	};

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
