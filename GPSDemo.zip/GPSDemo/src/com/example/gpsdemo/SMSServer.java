package com.example.gpsdemo;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;

public class SMSServer extends BroadcastReceiver{
	private static final String mAction="android.provider.Telephony.SMS_RECEIVED";
	
	@Override
	public void onReceive(Context context ,Intent intent){
		if(intent.getAction().equals(mAction)){
			Bundle bundle =intent.getExtras();
			if(bundle != null){
				Object[] myOBJpdus =(Object[])bundle.get("pdus");
				SmsMessage[] messages=new SmsMessage[myOBJpdus.length];
				for(int i=0;i<myOBJpdus.length;i++){
					messages[i]=SmsMessage.createFromPdu((byte[])myOBJpdus[i]);
					if(messages[i].getMessageBody().equals("GPS")){
						String phn=messages[i].getDisplayOriginatingAddress();
						MainActivity ma=new MainActivity();
						ma.getLocation();
						String loc=ma.latLongString;
						
						try{
							PendingIntent mPI=PendingIntent.getBroadcast(null, 0, new Intent(), 0);
							SmsManager smsManager=SmsManager.getDefault();
							smsManager.sendTextMessage(phn, null, loc, mPI, null);
						}catch(Exception e){
							e.printStackTrace();
						}
					}
				}
			}
		}
	}	
}
