package domain;

public class Users {
private int id;
private String name;
private String psw;
private String img;
/**
 * @return the id
 */
public int getId() {
	return id;
}
/**
 * @param id the id to set
 */
public void setId(int id) {
	this.id = id;
}
/**
 * @return the name
 */
public String getName() {
	return name;
}
/**
 * @param name the name to set
 */
public void setName(String name) {
	this.name = name;
}
/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
@Override
public String toString() {
	return "Users [id=" + id + ", name=" + name + ", psw=" + psw + ", img="
			+ img + "]";
}
/**
 * @return the psw
 */
public String getPsw() {
	return psw;
}
/**
 * @param psw the psw to set
 */
public void setPsw(String psw) {
	this.psw = psw;
}
/**
 * @return the img
 */
public String getImg() {
	return img;
}
/**
 * @param img the img to set
 */
public void setImg(String img) {
	this.img = img;
}
}
