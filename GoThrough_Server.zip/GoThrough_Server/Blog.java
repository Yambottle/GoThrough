package domain;

public class Blog {
	private int BL_id;
	private String BL_name;
	private String BL_text;
	private int BL_uId;
	private int BL_lId;

	/**
	 * @return the bL_id
	 */
	public int getBL_id() {
		return BL_id;
	}

	/**
	 * @param bL_id
	 *            the bL_id to set
	 */
	public void setBL_id(int bL_id) {
		BL_id = bL_id;
	}

	/**
	 * @return the bL_name
	 */
	public String getBL_name() {
		return BL_name;
	}

	/**
	 * @param bL_name
	 *            the bL_name to set
	 */
	public void setBL_name(String bL_name) {
		BL_name = bL_name;
	}

	/**
	 * @return the bL_text
	 */
	public String getBL_text() {
		return BL_text;
	}

	/**
	 * @param bL_text
	 *            the bL_text to set
	 */
	public void setBL_text(String bL_text) {
		BL_text = bL_text;
	}

	/**
	 * @return the bL_uId
	 */
	public int getBL_uId() {
		return BL_uId;
	}

	/**
	 * @param bL_uId
	 *            the bL_uId to set
	 */
	public void setBL_uId(int bL_uId) {
		BL_uId = bL_uId;
	}

	/**
	 * @return the bL_lId
	 */
	public int getBL_lId() {
		return BL_lId;
	}

	/**
	 * @param bL_lId
	 *            the bL_lId to set
	 */
	public void setBL_lId(int bL_lId) {
		BL_lId = bL_lId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Blog [BL_id=" + BL_id + ", BL_name=" + BL_name + ", BL_text="
				+ BL_text + ", BL_uId=" + BL_uId + ", BL_lId=" + BL_lId + "]";
	}

}
