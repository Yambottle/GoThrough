package domain;

public class Location {
	private int LC_id;
	private String LC_name;
	private String LC_lable;
	private Float LC_longitude;
	private Float LC_latitude;

	/**
	 * @return the lC_id
	 */
	public int getLC_id() {
		return LC_id;
	}

	/**
	 * @param lC_id the lC_id to set
	 */
	public void setLC_id(int lC_id) {
		LC_id = lC_id;
	}

	/**
	 * @return the lC_name
	 */
	public String getLC_name() {
		return LC_name;
	}

	/**
	 * @param lC_name
	 *            the lC_name to set
	 */
	public void setLC_name(String lC_name) {
		LC_name = lC_name;
	}

	/**
	 * @return the lC_lable
	 */
	public String getLC_lable() {
		return LC_lable;
	}

	/**
	 * @param lC_lable
	 *            the lC_lable to set
	 */
	public void setLC_lable(String lC_lable) {
		LC_lable = lC_lable;
	}

	/**
	 * @return the lC_longitude
	 */
	public Float getLC_longitude() {
		return LC_longitude;
	}

	/**
	 * @param lC_longitude the lC_longitude to set
	 */
	public void setLC_longitude(Float lC_longitude) {
		LC_longitude = lC_longitude;
	}

	/**
	 * @return the lC_latitude
	 */
	public Float getLC_latitude() {
		return LC_latitude;
	}

	/**
	 * @param lC_latitude the lC_latitude to set
	 */
	public void setLC_latitude(Float lC_latitude) {
		LC_latitude = lC_latitude;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Location [LC_id=" + LC_id + ", LC_name=" + LC_name
				+ ", LC_lable=" + LC_lable + ", LC_longitude=" + LC_longitude
				+ ", LC_latitude=" + LC_latitude + "]";
	}

	


}
