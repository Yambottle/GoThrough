package domain;

public class Picture {
	private int PI_id;
	private int PI_uId;
	private int PI_lId;
	private int PI_bId;
	private String PI_path;
	
	/**
	 * @return the pI_id
	 */
	public int getPI_id() {
		return PI_id;
	}
	/**
	 * @param pI_id the pI_id to set
	 */
	public void setPI_id(int pI_id) {
		PI_id = pI_id;
	}
	/**
	 * @return the pI_uId
	 */
	public int getPI_uId() {
		return PI_uId;
	}
	/**
	 * @param pI_uId the pI_uId to set
	 */
	public void setPI_uId(int pI_uId) {
		PI_uId = pI_uId;
	}
	/**
	 * @return the pI_lId
	 */
	public int getPI_lId() {
		return PI_lId;
	}
	/**
	 * @param pI_lId the pI_lId to set
	 */
	public void setPI_lId(int pI_lId) {
		PI_lId = pI_lId;
	}
	/**
	 * @return the pI_bId
	 */
	public int getPI_bId() {
		return PI_bId;
	}
	/**
	 * @param pI_bId the pI_bId to set
	 */
	public void setPI_bId(int pI_bId) {
		PI_bId = pI_bId;
	}
	/**
	 * @return the pI_path
	 */
	public String getPI_path() {
		return PI_path;
	}
	/**
	 * @param pI_path the pI_path to set
	 */
	public void setPI_path(String pI_path) {
		PI_path = pI_path;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Picture [PI_uId=" + PI_uId + ", PI_lId=" + PI_lId + ", PI_bId="
				+ PI_bId + ", PI_path=" + PI_path + "]";
	}
	
}
